{

    "metadata" :
    {
        "formatVersion" : 3.1,
        "sourceFile"    : "dice.obj",
        "generatedBy"   : "OBJConverter",
        "vertices"      : 8,
        "faces"         : 6,
        "normals"       : 6,
        "uvs"           : 22,
        "materials"     : 1
    },

    "materials": [	{
	"DbgColor" : 15658734,
	"DbgIndex" : 0,
	"DbgName" : "Material",
	"colorAmbient" : [0.207916, 0.207916, 0.207916],
	"colorDiffuse" : [0.8, 0.8, 0.8],
	"colorSpecular" : [1.0, 1.0, 1.0],
	"illumination" : 0,
	"mapDiffuse" : "dice.png",
	"opticalDensity" : 1.0,
	"specularCoef" : 96.078431,
	"transparency" : 1.0
	}],

    "buffers": "dice_bin.bin"

}
